require("__MT-lib__.basic")
if MTbasic.space_dlc() then
	require("prototypes.starmap-layers")
	require("prototypes.planet")
end