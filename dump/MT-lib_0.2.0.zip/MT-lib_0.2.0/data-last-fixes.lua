require("__MT-lib__.basic")
if MTbasic.space_dlc() then
	require("prototypes.fusion-reactor-tweaks")
	require("prototypes.standardisation")
	require("prototypes.location")
	require("prototypes.graphics")
	require("prototypes.final")
end